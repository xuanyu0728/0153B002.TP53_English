# Scientist’s Mission (0153B002, 陳萱玉)
[GitHub Repository](https://github.com/xuanyu0728/0153B002)

## Who Stole TP53’s Superpower? Searching for the Key to Unlock Cancer
### Using AI to Uncover the Secrets of TP53–DNA Interactions

---

### 1. 【The LEGO Assembly Line】
**Question:** What type of bond links amino acids together to form a protein? Which amino acids form hydrogen bonds with each other?

**Answer:**
![Protein Structure](image/image_1.png)

---

### 2. 【The Double-Track Highway of Life’s Blueprint】
**Question:** How do nucleotides assemble to form double-stranded DNA? What are the basic structural components of DNA? Is DNA right-handed or left-handed? List the names of the four DNA bases. Which bases form hydrogen bonds with each other?

**Answer:**
![DNA Structure](image/image_2.png)

---

### 3. 【Searching for My One-and-Only Soulmate in the Universe: A 20-Base-Pair Love Code Hidden Among 3 Billion DNA Base Pairs】
**The source of molecular stability and specificity: hydrogen bonding — How do TP53 and DNA recognize each other?**

**Question:** Using the structure 3KMD, identify one pair of an amino acid and a DNA base that interact with each other.

**Answer:**
![TP53-DNA Overview](image/image_3_1.png)
![ARG 280 Detail](image/image_3_2.png)

---

### 4. 【Return to the Crime Scene】
**Question:** Why can a mutation (change) in just one amino acid of a protein sometimes lead to a serious human disease? Give one specific example of such a disease.

**Answer:**

---

### 5. 【Return to the Crime Scene: Searching for Clues】
**Question:** Using the TP53–DNA structure (3KMD), identify one TP53 amino acid mutation that can lead to uncontrolled cell division and contribute to the development of cancer.
Then examine this amino acid in ChimeraX. Based on its three-dimensional position, determine whether the mutated amino acid is located directly at the protein–DNA interface or somewhere else in the protein.

**Answer:**
*Paste a screenshot of your ChimeraX visualization here.*
![ChimeraX Visualization 1](image/image_5_1.png)
![ChimeraX Visualization 2](image/image_5_2.png)

**b. Save your ChimeraX session file as StudentID.cxs.**
